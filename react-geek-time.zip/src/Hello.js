import React from "react";

export default () => (
  <div>
    <h1>Welcome to React course!</h1>
    <p>Click the left side menu to navigate.</p>
  </div>
);
