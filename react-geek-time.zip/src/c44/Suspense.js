import React from "react";
const link = "https://codesandbox.io/s/8nq4w3jj39";
export default () => (
  <a target="_blank" href={link}>
    {link}
  </a>
);
