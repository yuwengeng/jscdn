import React from "react";

export default () => (
  <a href="https://supnate.github.io/react-dom-diff/index.html" target="_blank">
    https://supnate.github.io/react-dom-diff/index.html
  </a>
);
