import React from "react";

const link =
  "http://demo.rekit.org/element/src%2Fcommon%2FconfigStore.js/code";
export default () => (
  <a href={link} target="_blank">
    {link}
  </a>
);
