import React from "react";

export default () => (
  <a
    href="http://demo.rekit.org/element/src%2Ffeatures%2Fhome%2Fredux%2FsaveFile.js/code"
    target="_blank"
  >
    http://demo.rekit.org/element/src%2Ffeatures%2Fhome%2Fredux%2FsaveFile.js/code
  </a>
);
